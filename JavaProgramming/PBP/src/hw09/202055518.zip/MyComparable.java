package hw09;

public interface MyComparable {
	public int compareTo(final MyComparable other) ;
	public long getSize() ;
}
