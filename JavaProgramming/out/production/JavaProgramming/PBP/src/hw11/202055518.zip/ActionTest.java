package hw11;

import javax.swing.*;

public class ActionTest { 
	public static void main(String[] args) { 
		final ActionFrame frame = new ActionFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}


